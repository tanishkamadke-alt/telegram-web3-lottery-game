import React from "react";
import ReactDOM from "react-dom/client";
import "./config/walletConnect";

import App from "./App";

import "./styles/globals.css";

import { WalletProvider } from "./context/WalletContext";
import { TelegramProvider } from "./context/TelegramContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <TelegramProvider>
      <WalletProvider>
        <App />
      </WalletProvider>
    </TelegramProvider>
  </React.StrictMode>
);