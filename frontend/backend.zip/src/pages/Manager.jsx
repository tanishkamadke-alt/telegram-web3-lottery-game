import { Crown } from "lucide-react";
import { useEffect, useState } from "react";
import { BrowserProvider, ethers } from "ethers";

import { showWinnerPopup } from "../utils/showWinnerPopup";

import {
  drawWinner,
  getManager,
  getCurrentRound,
  getTotalPlayers,
  getPrizePool,
  getLatestWinnerDetails,
} from "../services/contract";

function Manager({ refreshBlockchainData }) {

  const [loading, setLoading] = useState(false);
  const [isManager, setIsManager] = useState(false);

  const [managerAddress, setManagerAddress] = useState("");
  const [currentRound, setCurrentRound] = useState(0);
  const [players, setPlayers] = useState(0);
  const [prizePool, setPrizePool] = useState("0");

  async function loadManagerData() {

    try {

      if (!window.ethereum) return;

      const provider = new BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();

      const wallet = await signer.getAddress();

      const manager = await getManager(signer);
      setManagerAddress(manager);

      setIsManager(
        wallet.toLowerCase() ===
        manager.toLowerCase()
      );

      const round = await getCurrentRound(signer);
      setCurrentRound(Number(round));

      const totalPlayers = await getTotalPlayers(signer);
      setPlayers(Number(totalPlayers));

      const prize = await getPrizePool(signer);
      setPrizePool(prize);

    } catch (error) {

      console.error(error);

    }

  }

  useEffect(() => {

    loadManagerData();

  }, []);

  async function handleDrawWinner() {

    try {

      setLoading(true);

      const provider = new BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();

      await drawWinner(signer);

      if (refreshBlockchainData) {
        refreshBlockchainData();
      }

      await loadManagerData();

      const winnerData =
        await getLatestWinnerDetails(signer);

      if (winnerData) {

        showWinnerPopup({

          winner:
            winnerData.winner,

          prizeAmount:
            ethers.formatEther(
              winnerData.prizeAmount
            ),

          roundId:
            Number(
              winnerData.roundId
            ),

          totalPlayers:
            Number(
              winnerData.totalPlayers
            ),

          lotteryHash:
            winnerData.lotteryHash

        });

      }

    } catch (error) {

      console.error(error);

      alert(

        error.reason ||
        error.shortMessage ||
        error.message ||
        "Failed to draw winner."

      );

    } finally {

      setLoading(false);

    }

  }

  return (

    <div className="dashboard">

      <h1 className="dashboard-title">
        Manager Panel
      </h1>

      {

        !isManager ?

        (

          <div className="panel-card">

            <div className="panel-header">

              <div className="panel-icon">
                <Crown size={22}/>
              </div>

              <div>

                <h3 className="panel-title">
                  Access Denied
                </h3>

                <p className="panel-subtitle">
                  Only the contract manager can access this page.
                </p>

              </div>

            </div>

          </div>

        )

        :

        (

          <div className="panel-card">

            <div className="panel-header">

              <div className="panel-icon">
                <Crown size={22}/>
              </div>

              <div>

                <h3 className="panel-title">
                  Draw Winner
                </h3>

                <p className="panel-subtitle">
                  Lottery Administration
                </p>

              </div>

            </div>

            <div className="panel-info">

              <div className="info-row">

                <span>
                  Manager
                </span>

                <strong>

                  {

                    managerAddress

                    ?

                    `${managerAddress.slice(0,6)}...${managerAddress.slice(-4)}`

                    :

                    "-"

                  }

                </strong>

              </div>

              <div className="info-row">

                <span>
                  Current Round
                </span>

                <strong>
                  #{currentRound}
                </strong>

              </div>

              <div className="info-row">

                <span>
                  Players Joined
                </span>

                <strong>
                  {players}
                </strong>

              </div>

              <div className="info-row">

                <span>
                  Prize Pool
                </span>

                <strong>
                  {prizePool} ETH
                </strong>

              </div>

            </div>

            <button

              className="buy-button"

              onClick={handleDrawWinner}

              disabled={loading}

            >

              {

                loading

                ?

                "Drawing Winner..."

                :

                "Draw Winner"

              }

            </button>

          </div>

        )

      }

    </div>

  );

}

export default Manager;