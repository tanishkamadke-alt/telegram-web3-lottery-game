import { History as HistoryIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { ethers } from "ethers";

import { useWallet } from "../context/WalletContext";

import {
  getLotteryHistoryCount,
  getLotteryRound,
} from "../services/contract";

function History({ refreshKey }) {

  const { signer } = useWallet();

  const [history, setHistory] = useState([]);

  async function loadHistory() {

    if (!signer) return;

    try {

      const count = Number(
        await getLotteryHistoryCount(signer)
      );

      const rounds = [];

      for (let i = count - 1; i >= 0; i--) {

        const round = await getLotteryRound(
          signer,
          i
        );

        rounds.push({
          roundId: Number(round.roundId),
          winner: round.winner,
          prize: ethers.formatEther(
            round.prizeAmount
          ),
          totalPlayers: Number(
            round.totalPlayers
          ),
          timestamp: new Date(
            Number(round.timestamp) * 1000
          ).toLocaleString(),
        });

      }

      setHistory(rounds);

    } catch (error) {

      console.error(error);

    }

  }

  useEffect(() => {

    if (!signer) return;

    loadHistory();

  }, [refreshKey, signer]);

  return (

    <div className="dashboard">

      <h1 className="dashboard-title">
        Lottery History
      </h1>

      {

        history.length === 0 ?

        (

          <div className="panel-card">

            <div className="panel-header">

              <div className="panel-icon">
                <HistoryIcon size={22}/>
              </div>

              <div>

                <h3 className="panel-title">
                  Previous Lottery Rounds
                </h3>

                <p className="panel-subtitle">
                  No lottery rounds completed yet.
                </p>

              </div>

            </div>

          </div>

        )

        :

        (

          history.map((round) => (

            <div
              className="panel-card"
              key={round.roundId}
            >

              <div className="panel-header">

                <div className="panel-icon">
                  <HistoryIcon size={22}/>
                </div>

                <div>

                  <h3 className="panel-title">
                    Round #{round.roundId}
                  </h3>

                  <p className="panel-subtitle">
                    {round.timestamp}
                  </p>

                </div>

              </div>

              <div className="panel-info">

                <div className="winner-section">

                  <span className="winner-label">
                    Winner
                  </span>

                  <strong className="wallet-address">
                    {round.winner.slice(0,6)}...
                    {round.winner.slice(-4)}
                  </strong>

                </div>

                <div className="winner-section">

                  <span className="winner-label">
                    Prize
                  </span>

                  <strong>
                    {round.prize} ETH
                  </strong>

                </div>

                <div className="winner-section">

                  <span className="winner-label">
                    Players
                  </span>

                  <strong>
                    {round.totalPlayers}
                  </strong>

                </div>

              </div>

            </div>

          ))

        )

      }

    </div>

  );

}

export default History;