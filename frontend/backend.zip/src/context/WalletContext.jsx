import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useAppKit,
  useAppKitAccount,
  useAppKitProvider,
} from "@reown/appkit/react";

import { ethers } from "ethers";

const WalletContext = createContext(null);

export function WalletProvider({ children }) {
  const { open } = useAppKit();

  const { isConnected, address } = useAppKitAccount();

  const { walletProvider } = useAppKitProvider("eip155");

  const [signer, setSigner] = useState(null);
  const [chainId, setChainId] = useState(null);

  useEffect(() => {
    async function loadSigner() {
      if (!walletProvider) {
        setSigner(null);
        setChainId(null);
        return;
      }

      try {
        const provider = new ethers.BrowserProvider(walletProvider);

        const signer = await provider.getSigner();

        const network = await provider.getNetwork();
        setChainId(Number(network.chainId));

        const signerAddress = await signer.getAddress();
        const balance = await provider.getBalance(signerAddress);
        const blockNumber = await provider.getBlockNumber();

        console.log("Chain ID:", Number(network.chainId));
        console.log("Block Number:", blockNumber);
        console.log("Signer Address:", signerAddress);
        console.log("Balance:", ethers.formatEther(balance), "ETH");

        setSigner(signer);
      } catch (error) {
        console.error("Failed to initialize wallet:", error);
        setSigner(null);
        setChainId(null);
      }
    }

    loadSigner();
  }, [walletProvider]);

  const networkName = useMemo(() => {
    switch (chainId) {
      case 31337:
        return "Hardhat Local";

      case 11155111:
        return "Sepolia";

      default:
        return "Unknown";
    }
  }, [chainId]);

  async function connectWallet() {
    await open();
  }

  const value = {
    connected: isConnected,
    walletAddress: address ?? "",
    networkName,
    provider: walletProvider,
    signer,
    connectWallet,
  };

  return (
    <WalletContext.Provider value={value}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  return useContext(WalletContext);
}
