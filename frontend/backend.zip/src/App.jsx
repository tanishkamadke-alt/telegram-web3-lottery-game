import { useState } from "react";

import MainLayout from "./components/Layout/MainLayout";

import Dashboard from "./components/Dashboard/Dashboard";
import Manager from "./pages/Manager";
import History from "./pages/History";

import { useTelegram } from "./context/TelegramContext";
import { useWallet } from "./context/WalletContext";

function App() {
  console.log("App rendered");

  const [page, setPage] = useState("dashboard");
  const [refreshKey, setRefreshKey] = useState(0);

  const { telegramUser, insideTelegram } = useTelegram();

  const {
    walletAddress,
    connected,
    signer,
    connectWallet,
  } = useWallet();

  console.log("Telegram User:", telegramUser);
  console.log("Inside Telegram:", insideTelegram);

  function refreshBlockchainData() {
    setRefreshKey((prev) => prev + 1);
  }

  function renderPage() {
    switch (page) {
      case "manager":
        return (
          <Manager
            refreshBlockchainData={refreshBlockchainData}
          />
        );

      case "history":
        return (
          <History
            refreshKey={refreshKey}
          />
        );

      default:
        return (
          <Dashboard
            refreshKey={refreshKey}
          />
        );
    }
  }

  return (
    <MainLayout
      page={page}
      setPage={setPage}
    >
      {/* Temporary Wallet UI */}
      <div style={{ marginBottom: "20px" }}>
        <button onClick={connectWallet}>
          {connected ? "Wallet Connected" : "Connect Wallet"}
        </button>

        {walletAddress && (
          <p>
            <strong>Wallet:</strong> {walletAddress}
          </p>
        )}
      </div>

      {renderPage()}
    </MainLayout>
  );
}

export default App;
