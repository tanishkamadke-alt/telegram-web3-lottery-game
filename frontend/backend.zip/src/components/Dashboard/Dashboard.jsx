import { useEffect, useState } from "react";
import "./dashboard.css";
import { useWallet } from "../../context/WalletContext";

import Card from "../Common/Card";
import BuyTicket from "../Lottery/BuyTicket";
import LatestWinner from "../Lottery/LatestWinner";
import dashboardData from "../../data/dashboardData";

import {
  getCurrentRound,
  getTotalPlayers,
  getPrizePool,
} from "../../services/contract";

import {
  Trophy,
  Users,
  Coins,
  Ticket,
} from "lucide-react";

function Dashboard({ refreshKey }) {

  const { signer } = useWallet();
  const [currentRound, setCurrentRound] = useState(0);
  const [players, setPlayers] = useState(0);
  const [prizePool, setPrizePool] = useState("0");

  async function loadDashboardData() {
    if (!signer) {
  return;
}
    try {

      const round = await getCurrentRound(signer);
      setCurrentRound(Number(round));

      const totalPlayers = await getTotalPlayers(signer);
      setPlayers(Number(totalPlayers));

      const prize = await getPrizePool(signer);
      setPrizePool(prize);

      console.log("Current Round:", Number(round));
      console.log("Players:", Number(totalPlayers));
      console.log("Prize Pool:", prize);

    } catch (error) {

      console.error("Failed to load dashboard:", error);

    }
  }

  useEffect(() => {
    loadDashboardData();
  }, [refreshKey]);

  return (
    <div className="dashboard">

      <h1 className="dashboard-title">
        Dashboard
      </h1>

      <div className="stats-grid">

        <Card
          icon={<Trophy size={28} />}
          title="Current Round"
          value={currentRound}
          status={dashboardData.roundStatus}
        />

        <Card
          icon={<Users size={28} />}
          title="Players"
          value={players}
          status={dashboardData.playerStatus}
        />

        <Card
          icon={<Coins size={28} />}
          title="Prize Pool"
          value={`${prizePool} ETH`}
          status={dashboardData.prizeStatus}
        />

        <Card
          icon={<Ticket size={28} />}
          title="Ticket Price"
          value={dashboardData.ticketPrice}
          status={dashboardData.ticketStatus}
        />

      </div>

      <div className="dashboard-row">

        <BuyTicket
          ticketPrice={dashboardData.ticketPrice}
          currentRound={currentRound}
          onTicketPurchased={loadDashboardData}
        />

        <LatestWinner
          refreshKey={refreshKey}
        />

      </div>

      <div className="history-section"></div>

    </div>
  );
}

export default Dashboard;