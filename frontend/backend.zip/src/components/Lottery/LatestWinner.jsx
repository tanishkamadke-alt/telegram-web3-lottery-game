import { Trophy } from "lucide-react";
import { useEffect, useState } from "react";
import { ethers } from "ethers";

import { useWallet } from "../../context/WalletContext";

import {
  getLatestWinnerDetails,
} from "../../services/contract";

function LatestWinner() {
  const { signer } = useWallet();

  const [winner, setWinner] = useState("");
  const [prize, setPrize] = useState("0");
  const [round, setRound] = useState(0);

  useEffect(() => {
    if (!signer) return;

    async function loadWinner() {
      try {
        const latestRound =
          await getLatestWinnerDetails(signer);

        if (!latestRound) return;

        setWinner(latestRound.winner);

        setPrize(
          ethers.formatEther(
            latestRound.prizeAmount
          )
        );

        setRound(
          Number(latestRound.roundId)
        );

      } catch (error) {
        console.error(error);
      }
    }

    loadWinner();

  }, [signer]);

  return (
    <div className="panel-card">
      <div className="panel-header">
        <div className="panel-icon">
          <Trophy size={22} />
        </div>

        <div>
          <h3 className="panel-title">
            Latest Winner
          </h3>

          <p className="panel-subtitle">
            Most recent winner
          </p>
        </div>
      </div>

      <div className="panel-info">

        <div className="winner-section">
          <span className="winner-label">
            Winner Wallet
          </span>

          <strong className="wallet-address">
            {winner
              ? `${winner.slice(0, 6)}...${winner.slice(-4)}`
              : "No Winner"}
          </strong>
        </div>

        <div className="winner-section">
          <span className="winner-label">
            Prize Won
          </span>

          <strong>
            {prize} ETH
          </strong>
        </div>

        <div className="winner-section">
          <span className="winner-label">
            Winning Round
          </span>

          <strong>
            #{round}
          </strong>
        </div>

      </div>
    </div>
  );
}

export default LatestWinner;