import Swal from "sweetalert2";

export function showWinnerPopup(data) {

  Swal.fire({

    width: 520,

    background: "#1f2947",

    color: "#ffffff",

    allowOutsideClick: false,

    confirmButtonColor: "#18d4ff",

    confirmButtonText: "Awesome 🚀",

    showClass: {

      popup: "animate__animated animate__zoomIn"

    },

    hideClass: {

      popup: "animate__animated animate__zoomOut"

    },

    html: `

      <div style="padding:10px">

        <div style="font-size:70px;margin-bottom:10px">
          🏆
        </div>

        <h2 style="
          margin:0;
          color:#22d3ee;
          font-size:32px;">
          Winner Selected!
        </h2>

        <p style="
          color:#9ca3af;
          margin-bottom:30px;">
          Congratulations 🎉
        </p>

        <div style="
          background:#253454;
          border-radius:15px;
          padding:18px;
          text-align:left">

          <p><b>🏅 Winner</b><br>${data.winner}</p>

          <hr>

          <p><b>💰 Prize</b><br>${data.prizeAmount} ETH</p>

          <hr>

          <p><b>🎯 Round</b><br>#${data.roundId}</p>

          <hr>

          <p><b>👥 Players</b><br>${data.totalPlayers}</p>

          <hr>

          <p style="font-size:12px">

          <b>🔐 Lottery Hash</b><br>

          ${data.lotteryHash}

          </p>

        </div>

      </div>

    `

  });

}