import { ethers } from "ethers";

import { LOTTERY_ABI } from "../contracts/LotteryABI";
import { LOTTERY_CONTRACT_ADDRESS } from "../contracts/addresses";

export function getContract(signer) {
  if (!signer) {
    throw new Error("Wallet is not connected.");
  }

  return new ethers.Contract(
    LOTTERY_CONTRACT_ADDRESS,
    LOTTERY_ABI,
    signer
  );
}

export async function getCurrentRound(signer) {
  const contract = getContract(signer);

  return await contract.currentRound();
}

export async function buyTicket(signer) {
  const contract = getContract(signer);

  const tx = await contract.buyTicket({
    value: ethers.parseEther("0.01"),
  });

  await tx.wait();

  return tx;
}

export async function getTotalPlayers(signer) {
  const contract = getContract(signer);

  return await contract.getTotalPlayers();
}

export async function getPrizePool(signer) {
  const contract = getContract(signer);

  const balance = await contract.getContractBalance();

  return ethers.formatEther(balance);
}

export async function getLatestWinner(signer) {
  const contract = getContract(signer);

  return await contract.getLatestWinner();
}

export async function drawWinner(signer) {
  const contract = getContract(signer);

  const tx = await contract.drawWinner({
    gasLimit: 1000000,
  });

  await tx.wait();

  return tx;
}

export async function getLotteryHistoryCount(signer) {
  const contract = getContract(signer);

  return await contract.getLotteryHistoryCount();
}

export async function getLotteryRound(signer, index) {
  const contract = getContract(signer);

  return await contract.getLotteryRound(index);
}

export async function getLatestWinnerDetails(signer) {

  const contract = getContract(signer);

  const count = Number(
    await contract.getLotteryHistoryCount()
  );

  if (count === 0) {
    return null;
  }

  return await contract.getLotteryRound(count - 1);

}

export async function getManager(signer) {

  const contract = getContract(signer);

  return await contract.manager();

}


